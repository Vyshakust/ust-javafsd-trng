package com.ust.bus.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ust.bus.model.Bus;

public interface BusInterface extends JpaRepository<Bus,Long> {

}
