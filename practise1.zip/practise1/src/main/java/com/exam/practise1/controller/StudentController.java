package com.exam.practise1.controller;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.practise1.entity.Student;
import com.exam.practise1.exception.StudentException;
import com.exam.practise1.repository.StudentRepository;


@RestController
public class StudentController {
	
	@Autowired 
	private StudentRepository studentrepo;
	
	@GetMapping("/student/{id}")
	public ResponseEntity<Student> getStudentById(@PathVariable long id){
		
		Optional<Student> student=studentrepo.findById(id);
		if(student.isPresent()) {
			return new ResponseEntity<>(student.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	
	@GetMapping("/students/{name}")
	public ResponseEntity<Student> getStudentByName(@PathVariable String name){
		Optional<Student> s1 = studentrepo.findByName(name);
		if(s1.isPresent()) {
			return new ResponseEntity<>(s1.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	
	@GetMapping("/students")
	public ResponseEntity<List<Student>> getAllStudents(){
		return new ResponseEntity<>(studentrepo.findAll(),HttpStatus.OK);
	}
	
	
	@PostMapping("/students")
	public ResponseEntity<List<Student>> addStudent(@RequestBody List<Student> student){
		List<Student> s1=studentrepo.saveAll(student);
		return new ResponseEntity<>(s1,HttpStatus.OK);
	}
	
	@PutMapping("/students/{id}")
	public ResponseEntity<Student> updateStudent(@RequestBody Student student,@PathVariable long id)
	{
		Optional<Student> s1=studentrepo.findById(id);
		if(s1.isPresent()) {
			Student updated=s1.get();
			updated.setName(student.getName());
			studentrepo.save(updated);
			return new ResponseEntity<>(updated,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	
	@DeleteMapping("/students/{id}")
	public ResponseEntity<?> deleteStudent(@PathVariable long id){

		
		try {
//		if(s1.isPresent()) {
			Optional<Student> s1 =studentrepo.findById(id);
			studentrepo.delete(s1.get());
			return new ResponseEntity<>(s1.get(),HttpStatus.OK);
//		}
		
//		else {
//		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//	}
		}
		catch(IllegalArgumentException e) {
			StudentException e1=new StudentException("606","The give rollnumber is null"+e.getMessage());
			return new ResponseEntity<StudentException>(e1,HttpStatus.BAD_REQUEST);
		}
		
		catch(NoSuchElementException e) {
			StudentException e1=new StudentException("607","The give rollnumber is not found"+e.getMessage());
			return new ResponseEntity<StudentException>(e1,HttpStatus.BAD_REQUEST);
		}
	}

}
