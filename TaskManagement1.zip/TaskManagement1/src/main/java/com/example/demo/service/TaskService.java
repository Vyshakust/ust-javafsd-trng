package com.example.demo.service;

import java.util.List;
import java.util.NoSuchElementException;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Task;
import com.example.demo.repo.TaskRepo;

@Service
public class TaskService {
	
	@Autowired
	TaskRepo taskrepo;
	
	@Transactional
	public List<Task> getAllTask(){
		return taskrepo.findAll();
	}
	
	@Transactional
	public Task getTaskById(long id) {
		Task result = taskrepo.findById(id).orElseThrow(()->new NoSuchElementException("jhg"));
		return result;
	}
	
	@Transactional
	public Task addTask(Task l2) {
		taskrepo.save(l2);
		return l2;
	}
	
	@Transactional
	public void updatetask_status(long id, Task t1) {
		
		Task t=taskrepo.findById(id).orElseThrow(()->new NoSuchElementException());
		if(t1.getStatus()!=null) {
			t.setStatus(t1.getStatus());
		}
	}
	
	@Transactional
	public void deleteTask(long id) {
		
		Task t=taskrepo.findById(id).orElseThrow(()->new NoSuchElementException("no element"));
		// TODO Auto-generated method stub
		taskrepo.delete(t);
		
	}

	
}
