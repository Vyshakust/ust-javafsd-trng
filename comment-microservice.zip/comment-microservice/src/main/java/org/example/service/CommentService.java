package org.example.service;

import org.example.domain.Comment;
import org.example.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CommentService {
    @Autowired
    private CommentRepository commentRepository;


    public Comment addComment(Comment comment){
        return commentRepository.save(comment);
    }

    




    public void deleteUser(String id) {
        commentRepository.deleteById(id);
    }

    public Comment findCommentById(String id)
    {
        Optional<Comment> result = commentRepository.findById(id);
        Comment comment = result.get();
        return comment;
    }
}
