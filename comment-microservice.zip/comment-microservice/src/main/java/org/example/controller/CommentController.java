package org.example.controller;
import org.example.domain.Comment;
import org.example.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/comments")
public class CommentController {

    @Autowired
    private CommentService commentService;

    @PostMapping("/create")
    public ResponseEntity<Comment> createComment(@RequestBody Comment comment){
        return ResponseEntity.ok().body(commentService.addComment(comment));
    }
    @GetMapping("/user/{id}")
    public Comment getUser(@PathVariable String id) {
        Comment user= commentService.findCommentById(id);
        return user;
    }
    @DeleteMapping("/user/{id}")
    public ResponseEntity<Comment> deleteUser(@PathVariable String id) {
        commentService.deleteUser(id);
        return new ResponseEntity<Comment>(HttpStatus.OK);
    }
    }




