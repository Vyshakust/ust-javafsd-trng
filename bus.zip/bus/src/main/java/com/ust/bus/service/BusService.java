package com.ust.bus.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.bus.model.Bus;
import com.ust.bus.repository.BusInterface;


@Service
public class BusService {
	
	@Autowired
	private BusInterface busrepo;
	
	public List<Bus> getAllBus(){
		return busrepo.findAll();
	}
	
	public Optional<Bus> findBus(long id){
		Optional<Bus> v1=busrepo.findById(id);
		return v1;
	}
	
	public Bus addBus(Bus v) {
		Bus v1 = busrepo.save(v);
		return v1;
	}
	
	public Optional<Bus> updateBus(Bus v,long id) {
		Optional<Bus> v1=busrepo.findById(id);
		if(v1.isPresent()) {
			v1.get().setRoute(v.getRoute());
			v1.get().setArrivalTime(v.getArrivalTime());
			v1.get().setDepartureTime(v.getDepartureTime());
			v1.get().setDuration(v.getDuration());
			v1.get().setVendorid(v.getVendorid());
			busrepo.save(v1.get());
			return v1;
		}
		else {
			return v1;
		}
	}
	
	public Optional<Bus> deleteBus(long id){
		Optional<Bus> v1=busrepo.findById(id);
		if(v1.isPresent()) {
		busrepo.delete(v1.get());
		return v1;
		}
		else {
			return v1;
		}
		
	}

}
