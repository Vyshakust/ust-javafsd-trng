package com.ust.bus.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ust.bus.model.Bus;
import com.ust.bus.service.BusService;


@RestController
public class BusController {
	@Autowired
	private BusService busservice;
	

	@GetMapping("/bus")
	public ResponseEntity<List<Bus>> getAllBus(){
		return new ResponseEntity<>(busservice.getAllBus(),HttpStatus.OK);
	}

	@GetMapping("/bus/{id}")
	public ResponseEntity<Bus> getBus(@PathVariable long id){
		Optional<Bus> v1=busservice.findBus(id);
		if(v1.isPresent()) {
			return new ResponseEntity<>(v1.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	
	@PostMapping("/bus")
	public ResponseEntity<Bus> addVendor(@RequestBody Bus v1){
		return new ResponseEntity<>(busservice.addBus(v1),HttpStatus.OK);
	}
	
	@PutMapping("/bus/{id}")
	public ResponseEntity<Bus> updateBus(@PathVariable long id,@RequestBody Bus v1){
		Optional<Bus> v=busservice.updateBus(v1, id);
		if(v.isPresent()) {
			return new ResponseEntity<>(v.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	
	@DeleteMapping("/vendors/{id}")
	public ResponseEntity<Bus> deleteBus(@PathVariable long id){
		Optional<Bus> v=busservice.deleteBus(id);
		if(v.isPresent()) {
			return new ResponseEntity<>(v.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	

}
