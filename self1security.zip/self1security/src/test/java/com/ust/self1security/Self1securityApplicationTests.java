package com.ust.self1security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Self1securityApplicationTests {

	@Test
	void contextLoads() {
	}

}
