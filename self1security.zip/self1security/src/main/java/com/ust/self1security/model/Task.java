package com.ust.self1security.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="task1")
public class Task {

	@Id
	@Column(name="task_id")
	private int id;
	
	@Column(name="task_name")
	private String taskname;
	
	@Column(name="task_status")
	private String status;
	
	@Column(name="task_comments")
	private String comments;
	

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTaskname() {
		return taskname;
	}

	public void setTaskname(String taskname) {
		this.taskname = taskname;
	}

	@Override
	public String toString() {
		return "Task [id=" + id + ", taskname=" + taskname + ", status=" + status + ", comments=" + comments + "]";
	}

	
	
	
}

