package com.ust.self1security.service;

import java.util.List;
import java.util.NoSuchElementException;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.self1security.model.Task;
import com.ust.self1security.repository.TaskRepository;




@Service
public class TaskService {

		@Autowired
		TaskRepository taskrepo;

		@Transactional
		public Task getTaskById(int id) {
			Task result = taskrepo.findById(id).orElseThrow(()->new NoSuchElementException("jhg"));
			return result;
		}

		@Transactional
		public List<Task> getAllTasks() {
			List<Task> l1=taskrepo.findAll();
			return l1;
		}

		@Transactional
		public List<Task> addTask(List<Task> l2) {
			taskrepo.saveAll(l2);
			return l2;
		}

		@Transactional
		public void updatetask(int id, Task t1) {
			Task t=taskrepo.findById(id).orElseThrow(()->new NoSuchElementException("no element"));
			t.setTaskname(t1.getTaskname());
		}

		
		@Transactional
		public void deleteTask(int id) {
			
			Task t=taskrepo.findById(id).orElseThrow(()->new NoSuchElementException("no element"));
			// TODO Auto-generated method stub
			taskrepo.delete(t);
			
		}

		@Transactional
		public void updatetask_status(int id, Task t1) {
			
			Task t=taskrepo.findById(id).orElseThrow(()->new NoSuchElementException());
			if(t1.getStatus()!=null) {
				t.setStatus(t1.getStatus());
			}
			if(t1.getComments()!=null) {
				t.setComments(t1.getComments());
			}
			
		}
		
		
		
}
