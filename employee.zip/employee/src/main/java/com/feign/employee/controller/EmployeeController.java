package com.feign.employee.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.feign.employee.Department.Organisation;
import com.feign.employee.model.Employee;
import com.feign.employee.service.EmployeeService;



@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeservice;
	
	@GetMapping("/employee/organisation/{id}")
	public ResponseEntity<?> getEmployeeOrganisation(@PathVariable long id){
		return new ResponseEntity<>(employeeservice.getEmployeeOrganisation(id),HttpStatus.OK);
		
	}
	
	@GetMapping("/employee")
	public ResponseEntity<List<Employee>> getAllVendors(){
		return new ResponseEntity<>(employeeservice.getAllEmployee(),HttpStatus.OK);
	}

	@GetMapping("/employee/{id}")
	public ResponseEntity<Employee> getVendors(@PathVariable long id){
		Optional<Employee> v1=employeeservice.findEmployee(id);
		if(v1.isPresent()) {
			return new ResponseEntity<>(v1.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	
	@PostMapping("/employee")
	public ResponseEntity<Employee> addVendor(@RequestBody Employee v1){
		return new ResponseEntity<>(employeeservice.addEmployee(v1),HttpStatus.OK);
	}
	
	@PutMapping("/employee/{id}")
	public ResponseEntity<Employee> updateVendor(@PathVariable long id,@RequestBody Employee v1){
		Optional<Employee> v=employeeservice.updateEmployee(v1, id);
		if(v.isPresent()) {
			return new ResponseEntity<>(v.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	
	@DeleteMapping("/employee/{id}")
	public ResponseEntity<Employee> deleteVendor(@PathVariable long id){
		Optional<Employee> v=employeeservice.deleteEmployee(id);
		if(v.isPresent()) {
			return new ResponseEntity<>(v.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}

}
