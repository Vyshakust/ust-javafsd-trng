package com.feign.employee.Department;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class Organisation implements OrganisationClient{

	@Override
	public ResponseEntity<?> getOrganisationById(Long id) {
		// TODO Auto-generated method stub
		return new ResponseEntity<>(HttpStatus.BAD_GATEWAY);
	}


	

}
